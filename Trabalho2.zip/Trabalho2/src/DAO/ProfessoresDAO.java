/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import trabalho2.Conexao;
import trabalho2.Professores;

/**
 *
 * @author berna
 */
public class ProfessoresDAO {
    
    private Connection conn;
    
    public ProfessoresDAO(){
        this.conn = (Connection) new Conexao().getConexao();
    }
    
    public void cadastrar (Professores professores){
        String sql = "INSERT INTO professores (nome,email) VALUES (?,?);";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,professores.getNome());
            stmt.setString(2,professores.getEmail());

            stmt.execute();
        } catch(SQLException ex) {
            System.out.println("Erro ao cadastrar pessoa: " + ex.getMessage());
        }
    }
    
    
    public void editar(Professores professores) {
        String sql = "UPDATE professores SET nome=?, email=? WHERE id=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, professores.getNome());
            stmt.setString(2, professores.getEmail());
            stmt.setInt(3, professores.getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar professor: " + ex.getMessage());
        }
    }
    
    public void excluir(int id) {
        String sql = "DELETE FROM professores WHERE id=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir professor: " + ex.getMessage());
        }
    }
    
    public List<Professores> getProfessoresNome(String nome){
        String sql = "SELECT * FROM professores WHERE nome LIKE ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%"+nome+"%");

            ResultSet rs = stmt.executeQuery();
            List<Professores> listaProfessores = new ArrayList();

            while (rs.next()){
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                listaProfessores.add(p);

            }

            return listaProfessores;
        }catch (SQLException ex){
                System.out.println("Erro ao consultar todas as professores" + ex.getMessage());
                return null;
        }
    }
    
    public Professores getProfessor (int id){
        String sql = "SELECT * FROM professores WHERE id = ?";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            Professores p = new Professores();
            
            rs.first();
            
            p.setId(rs.getInt("id"));
            p.setEmail(rs.getString("email"));
            p.setNome(rs.getString("nome"));

            return p;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar professores: " + ex.getMessage());
            return null;
        }
        
        
    }
    
    public List<Professores> getProfessores(){
        
        String sql = "SELECT * FROM professores";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Professores> listaProfessores = new ArrayList();
            
            while(rs.next()){
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setEmail("email");
                listaProfessores.add(p);
            }
            return listaProfessores;
        }catch (SQLException ex){
            System.out.println("Erro ao consultar todas as professores: " + ex.getMessage());
            return null;
        } 
    }
}
