package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import trabalho2.Conexao;
import trabalho2.Disciplinas;
import trabalho2.Professores;

public class DisciplinasDAO {
    private Connection conn;

    public DisciplinasDAO() {
        this.conn = new Conexao().getConexao();
    }

    
    public void cadastrar(Disciplinas disciplina) {
        String sql = "INSERT INTO disciplinas (nome, carga_horaria, professor_id) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, disciplina.getNomeDisciplina());
            stmt.setInt(2, disciplina.getCarga_horaria());
            stmt.setInt(3, disciplina.getProfessorId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar disciplina: " + ex.getMessage());
        }
    }

    
    public void editar(Disciplinas disciplina) {
        String sql = "UPDATE disciplinas SET nome=?, carga_horaria=?, professor_id=? WHERE id=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, disciplina.getNomeDisciplina());
            stmt.setInt(2, disciplina.getCarga_horaria());
            stmt.setInt(3, disciplina.getProfessorId());
            stmt.setInt(4, disciplina.getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar disciplina: " + ex.getMessage());
        }
    }

    
    public void excluir(int id) {
        String sql = "DELETE FROM disciplinas WHERE id=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir disciplina: " + ex.getMessage());
        }
    }
    
    public Disciplinas getDisciplina(int id) {
    String sql = "SELECT * FROM disciplinas WHERE id = ?";

    try {
        PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        if (rs.first()) {
            Disciplinas d = new Disciplinas();

            d.setId(rs.getInt("id"));
            d.setNomeDisciplina(rs.getString("nome"));
            d.setCarga_horaria(rs.getInt("carga_horaria"));
            d.setProfessorId(rs.getInt("professor_id")); // agora apenas o ID

            rs.close();
            stmt.close();
            return d;
        } else {
            return null; // disciplina não encontrada
        }

    } catch (SQLException ex) {
        System.out.println("Erro ao consultar disciplina: " + ex.getMessage());
        return null;
    }
}
    
    public List<Disciplinas> getDisciplinasNome(String nomeFiltro) {
    List<Disciplinas> lista = new ArrayList<>();
    String sql = "SELECT * FROM disciplinas WHERE nome LIKE ?";

    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, "%" + nomeFiltro + "%"); // busca parcial
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Disciplinas d = new Disciplinas();
            d.setId(rs.getInt("id"));
            d.setNomeDisciplina(rs.getString("nome"));
            d.setCarga_horaria(rs.getInt("carga_horaria"));
            d.setProfessorId(rs.getInt("professor_id"));
            lista.add(d);
        }

        rs.close();
    } catch (SQLException ex) {
        System.out.println("Erro ao listar disciplinas: " + ex.getMessage());
    }

    return lista;
}

}
