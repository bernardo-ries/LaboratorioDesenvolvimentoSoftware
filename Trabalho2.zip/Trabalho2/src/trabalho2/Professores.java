/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho2;

import java.sql.Connection;

/**
 *
 * @author berna
 */
public class Professores {
    private int id;
    private String nome;
    private String email;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    //RETORNAR O NOME NA COMBO BOX
    @Override
    public String toString() {
    return this.getNome();
    }
    
    // AS LINHAS DE BAIXO SERVEM PARA SOBRESCREVER O EQUALS() DA CLASSE PROFESSOR, PARA ATUALIZAR A COMBOBOX
    @Override
    public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    Professores other = (Professores) obj;
    return this.id == other.id;
}

    @Override
    public int hashCode() {
    return Integer.hashCode(id);
    }
}
