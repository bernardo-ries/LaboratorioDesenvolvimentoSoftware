package com.example.projetoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoApiApplication.class, args);
        System.out.println("PRINT");
    }

}
