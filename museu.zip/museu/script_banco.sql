DROP DATABASE IF EXISTS biblioteca_museu2;
CREATE DATABASE biblioteca_museu2;
USE biblioteca_museu2;

CREATE TABLE USUARIO (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    login VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('ADM', 'COMUM') NOT NULL
);

CREATE TABLE EDITORA (
    id_editora INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE AUTOR (
    id_autor INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE ASSUNTO (
    id_assunto INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE LIVRO (
    id_livro INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(150) NOT NULL,
    ano INT,
    isbn VARCHAR(20),
    numero_paginas INT,
    idioma VARCHAR(50),
    sinopse TEXT,
    id_editora INT,
    caminho_capa VARCHAR(255),
    status ENUM('ativo','inativo') DEFAULT 'ativo',
    id_usuario_resp INT,
    FOREIGN KEY (id_editora) REFERENCES EDITORA(id_editora),
    FOREIGN KEY (id_usuario_resp) REFERENCES USUARIO(id_usuario)
);

CREATE TABLE REVISTA (
    id_revista INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(150) NOT NULL,
    ano INT,
    issn VARCHAR(20),
    numero_edicao INT,
    numero_paginas INT,
    idioma VARCHAR(50),
    id_editora INT,
    caminho_capa VARCHAR(255),
    status ENUM('ativo','inativo') DEFAULT 'ativo',
    id_usuario_resp INT,
    FOREIGN KEY (id_editora) REFERENCES EDITORA(id_editora),
    FOREIGN KEY (id_usuario_resp) REFERENCES USUARIO(id_usuario)
);

-- Tabelas de Ligação (Muitos-para-Muitos)

CREATE TABLE LIVRO_AUTOR (
    id_livro INT,
    id_autor INT,
    PRIMARY KEY (id_livro, id_autor),
    FOREIGN KEY (id_livro) REFERENCES LIVRO(id_livro) ON DELETE CASCADE,
    FOREIGN KEY (id_autor) REFERENCES AUTOR(id_autor)
);

CREATE TABLE REVISTA_AUTOR (
    id_revista INT,
    id_autor INT,
    PRIMARY KEY (id_revista, id_autor),
    FOREIGN KEY (id_revista) REFERENCES REVISTA(id_revista) ON DELETE CASCADE,
    FOREIGN KEY (id_autor) REFERENCES AUTOR(id_autor)
);

CREATE TABLE LIVRO_ASSUNTO (
    id_livro INT,
    id_assunto INT,
    PRIMARY KEY (id_livro, id_assunto),
    FOREIGN KEY (id_livro) REFERENCES LIVRO(id_livro) ON DELETE CASCADE,
    FOREIGN KEY (id_assunto) REFERENCES ASSUNTO(id_assunto)
);

CREATE TABLE REVISTA_ASSUNTO (
    id_revista INT,
    id_assunto INT,
    PRIMARY KEY (id_revista, id_assunto),
    FOREIGN KEY (id_revista) REFERENCES REVISTA(id_revista) ON DELETE CASCADE,
    FOREIGN KEY (id_assunto) REFERENCES ASSUNTO(id_assunto)
);

CREATE TABLE LOGS (
    id_log INT PRIMARY KEY AUTO_INCREMENT,
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    acao TEXT NOT NULL,
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario)
);

INSERT INTO USUARIO (nome, login, senha, tipo) VALUES ('Administrador', 'admin', 'admin123', 'ADM');
