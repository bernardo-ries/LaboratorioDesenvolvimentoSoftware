package com.museu;

import com.museu.dao.*;
import com.museu.model.*;
import com.museu.util.GerenciadorArquivos;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.stage.*;
import java.io.File;
import java.util.List;

public class MuseuApp extends Application {

    private Usuario usuarioLogado = null;
    private BorderPane rootLayout;
    private FlowPane gridAcervo;
    
    private LivroDAO livroDAO = new LivroDAO();
    private RevistaDAO revistaDAO = new RevistaDAO();
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private LogDAO logDAO = new LogDAO();

    private File imagemCadastro = null;
    private File imagemEdicao = null;
    
    @Override
    public void start(Stage stage) {
        stage.setTitle("Museu Treze de Maio - Sistema Final v8");
        rootLayout = new BorderPane();
        rootLayout.setStyle("-fx-background-color: #f4f4f4;");
        
        criarHeader();
        exibirBusca(); 

        stage.setScene(new Scene(rootLayout, 1150, 800));
        stage.show();
    }

    private void criarHeader() {
        HBox header = new HBox(15);
        header.setPadding(new Insets(15));
        header.setStyle("-fx-background-color: #2c3e50;");
        header.setAlignment(Pos.CENTER_LEFT);

        Label lbl = new Label("Museu Treze de Maio");
        lbl.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl.setFont(Font.font("System", FontWeight.BOLD, 20));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnBusca = criarBotaoMenu("Acervo");
        Button btnAdmin = criarBotaoMenu("Administração");
        Button btnAjuda = criarBotaoMenu("Ajuda");

        btnBusca.setOnAction(e -> exibirBusca());
        btnAdmin.setOnAction(e -> {
            if(usuarioLogado == null) exibirLogin();
            else exibirDashboard();
        });
        btnAjuda.setOnAction(e -> exibirAjuda());

        header.getChildren().addAll(lbl, spacer, btnBusca, btnAdmin, btnAjuda);
        rootLayout.setTop(header);
    }
    
    private Button criarBotaoMenu(String texto) {
        Button b = new Button(texto);
        b.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-weight: bold;");
        b.setOnMouseEntered(e -> b.setStyle("-fx-background-color: rgba(255,255,255,0.2); -fx-text-fill: white;"));
        b.setOnMouseExited(e -> b.setStyle("-fx-background-color: transparent; -fx-text-fill: white;"));
        return b;
    }

    // --- TELA DE BUSCA ---
    private void exibirBusca() { exibirGridGenerica("Pesquisar no Acervo", false); }
    private void exibirInativos() { exibirGridGenerica("Lixeira / Itens Inativos", true); }
    
    private void exibirLogs() {
        VBox container = new VBox(20); container.setPadding(new Insets(20)); container.setAlignment(Pos.TOP_CENTER);
        Label lbl = new Label("Logs de Auditoria"); lbl.setFont(Font.font(24));
        
        TableView<Log> table = new TableView<>();
        TableColumn<Log, String> colData = new TableColumn<>("Data/Hora"); colData.setCellValueFactory(new PropertyValueFactory<>("dataHora")); colData.setPrefWidth(150);
        TableColumn<Log, String> colUser = new TableColumn<>("Usuário"); colUser.setCellValueFactory(new PropertyValueFactory<>("nomeUsuario")); colUser.setPrefWidth(150);
        TableColumn<Log, String> colAcao = new TableColumn<>("Ação"); colAcao.setCellValueFactory(new PropertyValueFactory<>("acao")); colAcao.setPrefWidth(500);
        
        table.getColumns().addAll(colData, colUser, colAcao);
        table.getItems().addAll(logDAO.listarTodos());
        
        Button btnVoltar = new Button("Voltar ao Painel");
        btnVoltar.setOnAction(e -> exibirDashboard());
        
        container.getChildren().addAll(lbl, table, btnVoltar);
        rootLayout.setCenter(container);
    }

    private void exibirGridGenerica(String titulo, boolean modoInativos) {
        VBox container = new VBox(20); container.setPadding(new Insets(20)); container.setAlignment(Pos.TOP_CENTER);
        Label lblTitulo = new Label(titulo); lblTitulo.setFont(Font.font(24));
        if(modoInativos) lblTitulo.setTextFill(javafx.scene.paint.Color.RED);

        HBox boxFiltros = new HBox(10); boxFiltros.setAlignment(Pos.CENTER);
        ComboBox<String> cbTipo = new ComboBox<>(); cbTipo.getItems().addAll("Todos", "Livros", "Revistas"); cbTipo.setValue("Todos");
        
        ComboBox<String> cbCampo = new ComboBox<>(); cbCampo.getItems().addAll("Título", "Autor", "Editora", "Ano", "ISBN/ISSN", "Assunto"); cbCampo.setValue("Título");
        
        TextField txtBusca = new TextField(); txtBusca.setPromptText("Digite sua busca..."); txtBusca.setPrefWidth(300);
        Button btnPesquisar = new Button("Buscar"); btnPesquisar.setDefaultButton(true);
        
        boxFiltros.getChildren().addAll(new Label("Tipo:"), cbTipo, new Label("Filtrar por:"), cbCampo, txtBusca, btnPesquisar);
        if(modoInativos) {
            Button btnVoltar = new Button("Voltar ao Painel"); btnVoltar.setOnAction(e -> exibirDashboard());
            boxFiltros.getChildren().add(btnVoltar);
        }

        ScrollPane scroll = new ScrollPane();
        gridAcervo = new FlowPane(20, 20); gridAcervo.setPadding(new Insets(20)); gridAcervo.setAlignment(Pos.TOP_CENTER);
        scroll.setContent(gridAcervo); scroll.setFitToWidth(true); scroll.setStyle("-fx-background: #f4f4f4; -fx-background-color: #f4f4f4;");

        btnPesquisar.setOnAction(e -> {
            String filtro = traduzirFiltro(cbCampo.getValue());
            realizarBusca(cbTipo.getValue(), filtro, txtBusca.getText(), !modoInativos);
        });
        realizarBusca("Todos", "titulo", "", !modoInativos);

        VBox.setVgrow(scroll, Priority.ALWAYS);
        container.getChildren().addAll(lblTitulo, boxFiltros, scroll);
        rootLayout.setCenter(container);
    }
    
    private String traduzirFiltro(String visivel) {
        if(visivel.equals("Título")) return "titulo";
        if(visivel.equals("Autor")) return "autor";
        if(visivel.equals("Editora")) return "editora";
        if(visivel.equals("Ano")) return "ano";
        if(visivel.equals("Assunto")) return "assunto";
        return "isbn";
    }

    private void realizarBusca(String tipo, String filtro, String termo, boolean apenasAtivos) {
        gridAcervo.getChildren().clear();
        
        if(tipo.equals("Todos") || tipo.equals("Livros")) {
            List<Livro> livros = livroDAO.pesquisar(filtro, termo, apenasAtivos);
            for(Livro l : livros) gridAcervo.getChildren().add(criarCard(l, apenasAtivos));
        }
        
        if((tipo.equals("Todos") || tipo.equals("Revistas")) && !filtro.equals("autor")) {
            List<Revista> revistas = revistaDAO.pesquisar(filtro, termo, apenasAtivos);
            for(Revista r : revistas) gridAcervo.getChildren().add(criarCard(r, apenasAtivos));
        }
        
        if(gridAcervo.getChildren().isEmpty()) gridAcervo.getChildren().add(new Label("Nenhum item encontrado."));
    }

    private VBox criarCard(Object item, boolean ativo) {
        VBox card = new VBox(5); card.setPadding(new Insets(10));
        card.setStyle("-fx-background-color: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 5, 0, 0, 1); -fx-background-radius: 5;");
        card.setPrefSize(160, 260); card.setAlignment(Pos.TOP_CENTER);

        String tituloTxt = "", caminho = "", tipoBadge = "";
        if(item instanceof Livro) {
            Livro l = (Livro) item; tituloTxt = l.getTitulo(); caminho = l.getCaminhoCapa(); tipoBadge = "LIVRO";
        } else if(item instanceof Revista) {
            Revista r = (Revista) item; tituloTxt = r.getTitulo(); caminho = r.getCaminhoCapa(); tipoBadge = "REVISTA";
        }

        ImageView img = new ImageView(); img.setFitWidth(140); img.setFitHeight(180); img.setPreserveRatio(true);
        try {
            if(caminho != null && !caminho.isEmpty()) img.setImage(new Image(new File(caminho).toURI().toString()));
            else img.setStyle("-fx-background-color: #ddd;"); 
        } catch(Exception e) {}
        
        if(img.getImage() == null) {
            Label placeholder = new Label(tipoBadge); placeholder.setPrefSize(140, 180);
            placeholder.setStyle("-fx-background-color: #eee; -fx-alignment: center; -fx-font-weight: bold; -fx-text-fill: #aaa;");
            card.getChildren().add(placeholder);
        } else card.getChildren().add(img);

        Label lblTitulo = new Label(tituloTxt); lblTitulo.setWrapText(true); lblTitulo.setTextAlignment(TextAlignment.CENTER); lblTitulo.setStyle("-fx-font-weight: bold;");
        Label lblTipo = new Label(tipoBadge); lblTipo.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");

        card.getChildren().addAll(lblTitulo, lblTipo);
        card.setOnMouseClicked(e -> exibirDetalhes(item, ativo));
        card.setStyle(card.getStyle() + "-fx-cursor: hand;");
        return card;
    }

    private void exibirDetalhes(Object item, boolean ativo) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        
        VBox content = new VBox(10); content.setPadding(new Insets(20)); content.setAlignment(Pos.CENTER);
        ImageView iv = new ImageView(); iv.setFitHeight(200); iv.setPreserveRatio(true);
        
        Label lblDet = new Label(); lblDet.setTextAlignment(TextAlignment.CENTER);
        TextArea txtSinopse = new TextArea(); txtSinopse.setEditable(false); txtSinopse.setWrapText(true); txtSinopse.setMaxHeight(100); txtSinopse.setVisible(false);

        if(item instanceof Livro) {
            Livro l = (Livro) item;
            dialog.setTitle("Detalhes do Livro"); dialog.setHeaderText(l.getTitulo());
            try { if(l.getCaminhoCapa()!=null) iv.setImage(new Image(new File(l.getCaminhoCapa()).toURI().toString())); } catch(Exception e){}
            lblDet.setText(String.format("Ano: %d | ISBN: %s\nPáginas: %d | Idioma: %s\nAssunto: %s\nEditora: %s | Autores: %s",
                l.getAno(), l.getIsbn(), l.getNumeroPaginas(), l.getIdioma(), l.getListaAssuntos(), l.getNomeEditora(), l.getNomesAutores()));
            if(l.getSinopse() != null && !l.getSinopse().isEmpty()) {
                txtSinopse.setText("SINOPSE:\n" + l.getSinopse()); txtSinopse.setVisible(true);
            }
        } else {
            Revista r = (Revista) item;
            dialog.setTitle("Detalhes da Revista"); dialog.setHeaderText(r.getTitulo());
            try { if(r.getCaminhoCapa()!=null) iv.setImage(new Image(new File(r.getCaminhoCapa()).toURI().toString())); } catch(Exception e){}
            lblDet.setText(String.format("Ano: %d | ISSN: %s\nEdição: %d | Páginas: %d\nIdioma: %s | Assunto: %s\nEditora: %s",
                r.getAno(), r.getIssn(), r.getNumeroEdicao(), r.getNumeroPaginas(), r.getIdioma(), r.getListaAssuntos(), r.getNomeEditora()));
        }

        content.getChildren().addAll(iv, lblDet);
        if(txtSinopse.isVisible()) content.getChildren().add(txtSinopse);
        
        if(usuarioLogado != null && "ADM".equals(usuarioLogado.getTipo())) {
            HBox botoes = new HBox(10); botoes.setAlignment(Pos.CENTER);
            if(ativo) {
                Button btnEditar = new Button("Editar"); btnEditar.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white;");
                btnEditar.setOnAction(e -> { dialog.close(); exibirDialogoEdicao(item); });
                Button btnExcluir = new Button("Excluir"); btnExcluir.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
                btnExcluir.setOnAction(e -> { alterarStatusItem(item, "inativo"); dialog.close(); if(rootLayout.getCenter() instanceof VBox) realizarBusca("Todos", "titulo", "", true); });
                botoes.getChildren().addAll(btnEditar, btnExcluir);
            } else {
                Button btnReativar = new Button("Reativar"); btnReativar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
                btnReativar.setOnAction(e -> { alterarStatusItem(item, "ativo"); dialog.close(); exibirInativos(); });
                botoes.getChildren().add(btnReativar);
            }
            content.getChildren().add(botoes);
        }
        dialog.getDialogPane().setContent(content);
        dialog.showAndWait();
    }
    
    private void alterarStatusItem(Object item, String status) {
        try {
            if(item instanceof Livro) {
                livroDAO.alterarStatus(((Livro)item).getId(), status);
                logDAO.registrarLog("Alterou status do livro " + ((Livro)item).getTitulo() + " para " + status, usuarioLogado);
            } else {
                revistaDAO.alterarStatus(((Revista)item).getId(), status);
                logDAO.registrarLog("Alterou status da revista " + ((Revista)item).getTitulo() + " para " + status, usuarioLogado);
            }
            mostrarMsg("Status alterado para: " + status);
        } catch(Exception e) { mostrarMsg("Erro: " + e.getMessage()); }
    }

    private void exibirDialogoEdicao(Object item) {
        Stage editStage = new Stage(); editStage.setTitle("Editar Item");
        VBox content = new VBox(15); content.setPadding(new Insets(20)); content.setAlignment(Pos.CENTER);
        GridPane form = new GridPane(); form.setVgap(10); form.setHgap(10); form.setAlignment(Pos.CENTER);

        TextField txtTitulo = new TextField(); TextField txtAno = new TextField();
        TextField txtPaginas = new TextField(); TextField txtIdioma = new TextField(); TextField txtAssunto = new TextField();
        TextField txtEditora = new TextField(); TextField txtCod = new TextField();
        TextArea txtSinopse = new TextArea(); txtSinopse.setWrapText(true); txtSinopse.setPrefRowCount(3);
        TextField txtCaminho = new TextField(); txtCaminho.setEditable(false); Button btnCapa = new Button("Alterar Capa");
        
        imagemEdicao = null;
        btnCapa.setOnAction(e -> {
            FileChooser fc = new FileChooser(); File f = fc.showOpenDialog(editStage);
            if(f!=null) { imagemEdicao=f; txtCaminho.setText(f.getName()); }
        });
        
        if(item instanceof Livro) {
            Livro l = (Livro) item;
            txtTitulo.setText(l.getTitulo()); txtAno.setText(""+l.getAno());
            txtPaginas.setText(""+l.getNumeroPaginas()); txtIdioma.setText(l.getIdioma()); txtAssunto.setText(l.getListaAssuntos());
            txtEditora.setText(l.getNomeEditora()); txtCod.setText(l.getIsbn()); txtSinopse.setText(l.getSinopse());
            txtCaminho.setText(l.getCaminhoCapa());
            form.addRow(0, new Label("Título:"), txtTitulo); form.addRow(1, new Label("Ano:"), txtAno);
            form.addRow(2, new Label("ISBN:"), txtCod); form.addRow(3, new Label("Páginas:"), txtPaginas);
            form.addRow(4, new Label("Idioma:"), txtIdioma); form.addRow(5, new Label("Assunto:"), txtAssunto);
            form.addRow(6, new Label("Sinopse:"), txtSinopse); form.addRow(7, new Label("Editora:"), txtEditora);
        } else {
            Revista r = (Revista) item;
            txtTitulo.setText(r.getTitulo()); txtAno.setText(""+r.getAno());
            txtPaginas.setText(""+r.getNumeroPaginas()); txtIdioma.setText(r.getIdioma()); txtAssunto.setText(r.getListaAssuntos());
            txtEditora.setText(r.getNomeEditora()); txtCod.setText(r.getIssn());
            txtCaminho.setText(r.getCaminhoCapa());
            form.addRow(0, new Label("Título:"), txtTitulo); form.addRow(1, new Label("Ano:"), txtAno);
            form.addRow(2, new Label("ISSN:"), txtCod); form.addRow(3, new Label("Páginas:"), txtPaginas);
            form.addRow(4, new Label("Idioma:"), txtIdioma); form.addRow(5, new Label("Assunto:"), txtAssunto);
            form.addRow(6, new Label("Editora:"), txtEditora);
        }
        form.add(new HBox(5, txtCaminho, btnCapa), 1, (item instanceof Livro ? 8 : 7));

        Button btnSalvar = new Button("Salvar Alterações"); btnSalvar.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        btnSalvar.setOnAction(e -> {
            try {
                String novoPath = (imagemEdicao!=null) ? GerenciadorArquivos.salvarImagem(imagemEdicao) : txtCaminho.getText();
                if(item instanceof Livro) {
                    Livro l = (Livro) item;
                    l.setTitulo(txtTitulo.getText()); l.setAno(Integer.parseInt(txtAno.getText()));
                    l.setNumeroPaginas(Integer.parseInt(txtPaginas.getText())); l.setIdioma(txtIdioma.getText());
                    l.setIsbn(txtCod.getText()); l.setCaminhoCapa(novoPath); l.setSinopse(txtSinopse.getText());
                    livroDAO.atualizar(l, txtEditora.getText(), txtAssunto.getText());
                    logDAO.registrarLog("Editou Livro: " + l.getTitulo(), usuarioLogado);
                } else {
                    Revista r = (Revista) item;
                    r.setTitulo(txtTitulo.getText()); r.setAno(Integer.parseInt(txtAno.getText()));
                    r.setNumeroPaginas(Integer.parseInt(txtPaginas.getText())); r.setIdioma(txtIdioma.getText());
                    r.setIssn(txtCod.getText()); r.setCaminhoCapa(novoPath);
                    revistaDAO.atualizar(r, txtEditora.getText(), txtAssunto.getText());
                    logDAO.registrarLog("Editou Revista: " + r.getTitulo(), usuarioLogado);
                }
                mostrarMsg("Atualizado com sucesso!"); editStage.close(); exibirBusca();
            } catch(Exception ex) { mostrarMsg("Erro ao salvar: " + ex.getMessage()); }
        });
        content.getChildren().addAll(form, btnSalvar);
        editStage.setScene(new Scene(content, 500, 500)); editStage.show();
    }

    private void exibirDashboard() {
        VBox content = new VBox(20); content.setPadding(new Insets(30)); content.setAlignment(Pos.TOP_CENTER);
        BorderPane headerDash = new BorderPane(); Label lbl = new Label("Cadastro de Obras"); lbl.setFont(Font.font(20)); headerDash.setLeft(lbl);
        HBox boxBotoesAdm = new HBox(15); boxBotoesAdm.setAlignment(Pos.CENTER_RIGHT);
        Button btnLixeira = new Button("Lixeira / Inativos"); btnLixeira.setStyle("-fx-background-color: #c0392b; -fx-text-fill: white;"); btnLixeira.setOnAction(e -> exibirInativos());
        Button btnLogs = new Button("Logs de Auditoria"); btnLogs.setStyle("-fx-background-color: #34495e; -fx-text-fill: white;"); btnLogs.setOnAction(e -> exibirLogs());
        boxBotoesAdm.getChildren().addAll(btnLixeira, btnLogs); headerDash.setRight(boxBotoesAdm);
        
        ToggleGroup grupoTipo = new ToggleGroup();
        RadioButton rbLivro = new RadioButton("Livro"); rbLivro.setToggleGroup(grupoTipo); rbLivro.setSelected(true);
        RadioButton rbRevista = new RadioButton("Revista"); rbRevista.setToggleGroup(grupoTipo);
        HBox boxTipo = new HBox(20, new Label("Tipo:"), rbLivro, rbRevista); boxTipo.setAlignment(Pos.CENTER);

        TextField txtTitulo = new TextField(); txtTitulo.setPromptText("Título");
        TextField txtAno = new TextField(); txtAno.setPromptText("Ano");
        TextField txtPaginas = new TextField(); txtPaginas.setPromptText("Nº Páginas");
        TextField txtIdioma = new TextField(); txtIdioma.setPromptText("Idioma");
        TextField txtAssunto = new TextField(); txtAssunto.setPromptText("Assunto (separar por vírgula)");
        TextField txtEditora = new TextField(); txtEditora.setPromptText("Editora");
        TextField txtCaminho = new TextField(); txtCaminho.setEditable(false); Button btnCapa = new Button("Capa");
        
        // Campos Livro
        TextField txtIsbn = new TextField(); txtIsbn.setPromptText("ISBN");
        TextField txtAutores = new TextField(); txtAutores.setPromptText("Autores (separados por vírgula)");
        TextArea txtSinopse = new TextArea(); txtSinopse.setPromptText("Sinopse"); txtSinopse.setPrefRowCount(3); txtSinopse.setWrapText(true);
        VBox boxLivro = new VBox(10, new Label("ISBN:"), txtIsbn, new Label("Autores:"), txtAutores, new Label("Sinopse:"), txtSinopse);
        
        // Campos Revista
        TextField txtIssn = new TextField(); txtIssn.setPromptText("ISSN");
        TextField txtEdicao = new TextField(); txtEdicao.setPromptText("Nº Edição");
        VBox boxRevista = new VBox(10, new Label("ISSN:"), txtIssn, new Label("Nº Edição:"), txtEdicao);
        boxRevista.setVisible(false); boxRevista.setManaged(false);

        rbLivro.setOnAction(e -> { boxLivro.setVisible(true); boxLivro.setManaged(true); boxRevista.setVisible(false); boxRevista.setManaged(false); });
        rbRevista.setOnAction(e -> { boxLivro.setVisible(false); boxLivro.setManaged(false); boxRevista.setVisible(true); boxRevista.setManaged(true); });
        
        imagemCadastro = null;
        btnCapa.setOnAction(e -> {
            FileChooser fc = new FileChooser(); File f = fc.showOpenDialog(null);
            if(f != null) { imagemCadastro = f; txtCaminho.setText(f.getName()); }
        });

        Button btnSalvar = new Button("CADASTRAR"); btnSalvar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;"); btnSalvar.setPrefWidth(200);
        
        btnSalvar.setOnAction(e -> {
            try {
                if(txtTitulo.getText().isEmpty() || txtAno.getText().isEmpty()) throw new Exception("Preencha campos obrigatórios.");
                String pathFinal = (imagemCadastro != null) ? GerenciadorArquivos.salvarImagem(imagemCadastro) : null;
                int pags = 0; try { pags = Integer.parseInt(txtPaginas.getText()); } catch(Exception ex){}

                if(rbLivro.isSelected()) {
                    Livro l = new Livro();
                    l.setTitulo(txtTitulo.getText()); l.setAno(Integer.parseInt(txtAno.getText()));
                    l.setNumeroPaginas(pags); l.setIdioma(txtIdioma.getText());
                    l.setIsbn(txtIsbn.getText()); l.setSinopse(txtSinopse.getText()); l.setCaminhoCapa(pathFinal);
                    livroDAO.salvar(l, txtEditora.getText(), txtAutores.getText(), txtAssunto.getText(), usuarioLogado.getId());
                    logDAO.registrarLog("Cadastrou Livro: " + l.getTitulo(), usuarioLogado);
                } else {
                    Revista r = new Revista();
                    r.setTitulo(txtTitulo.getText()); r.setAno(Integer.parseInt(txtAno.getText()));
                    r.setNumeroPaginas(pags); r.setIdioma(txtIdioma.getText());
                    r.setIssn(txtIssn.getText()); r.setCaminhoCapa(pathFinal);
                    try { r.setNumeroEdicao(Integer.parseInt(txtEdicao.getText())); } catch(Exception ex) { r.setNumeroEdicao(0); }
                    revistaDAO.salvar(r, txtEditora.getText(), txtAssunto.getText(), usuarioLogado.getId());
                    logDAO.registrarLog("Cadastrou Revista: " + r.getTitulo(), usuarioLogado);
                }
                mostrarMsg("Cadastro realizado!");
                txtTitulo.clear(); txtAno.clear(); txtEditora.clear(); txtCaminho.clear(); txtIsbn.clear(); txtAutores.clear();
                txtPaginas.clear(); txtIdioma.clear(); txtAssunto.clear(); txtSinopse.clear();
            } catch(Exception ex) { mostrarMsg("Erro: " + ex.getMessage()); }
        });

        GridPane form = new GridPane(); form.setVgap(10); form.setHgap(10); form.setAlignment(Pos.CENTER);
        form.addRow(0, new Label("Título:"), txtTitulo); form.addRow(1, new Label("Ano:"), txtAno);
        form.addRow(2, new Label("Páginas:"), txtPaginas); form.addRow(3, new Label("Idioma:"), txtIdioma);
        form.addRow(4, new Label("Assunto:"), txtAssunto); form.addRow(5, new Label("Editora:"), txtEditora);
        form.addRow(6, new Label("Capa:"), new HBox(5, txtCaminho, btnCapa));
        
        VBox layoutCampos = new VBox(20, boxTipo, form, boxLivro, boxRevista, btnSalvar);
        layoutCampos.setAlignment(Pos.CENTER); layoutCampos.setMaxWidth(600);
        content.getChildren().addAll(headerDash, layoutCampos);
        rootLayout.setCenter(content);
    }

    private void exibirLogin() {
        VBox box = new VBox(15); box.setAlignment(Pos.CENTER); box.setMaxWidth(300);
        TextField u = new TextField(); u.setPromptText("Login"); PasswordField p = new PasswordField(); p.setPromptText("Senha");
        Button b = new Button("Entrar");
        b.setOnAction(e -> {
            Usuario user = usuarioDAO.autenticar(u.getText(), p.getText());
            if(user != null && "ADM".equals(user.getTipo())) {
                usuarioLogado = user; logDAO.registrarLog("Login realizado com sucesso", usuarioLogado);
                mostrarMsg("Bem-vindo, " + user.getNome()); exibirDashboard();
            } else mostrarMsg("Dados inválidos");
        });
        box.getChildren().addAll(new Label("Área Restrita"), u, p, b); rootLayout.setCenter(box);
    }
    
    private void exibirAjuda() {
        Alert a = new Alert(Alert.AlertType.INFORMATION); a.setTitle("Ajuda"); a.setHeaderText("Instruções");
        a.setContentText("1. Use a busca para encontrar itens ativos.\n2. Admins podem editar e excluir itens.\n3. Itens excluídos vão para 'Inativos' e podem ser recuperados."); a.show();
    }
    private void mostrarMsg(String t) { Alert a = new Alert(Alert.AlertType.INFORMATION); a.setHeaderText(null); a.setContentText(t); a.show(); }
    public static void main(String[] args) { launch(args); }
}