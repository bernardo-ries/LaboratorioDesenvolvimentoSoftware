package com.museu;
public class Launcher {
    public static void main(String[] args) { MuseuApp.main(args); }
}