package com.museu.util;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
public class GerenciadorArquivos {
    private static final String PASTA_IMAGENS = "capas_acervo";
    public static String salvarImagem(File arquivoOriginal) throws IOException {
        File diretorio = new File(PASTA_IMAGENS);
        if (!diretorio.exists()) diretorio.mkdir();
        String nome = UUID.randomUUID().toString() + ".jpg";
        File destino = new File(diretorio, nome);
        Files.copy(arquivoOriginal.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return destino.getPath();
    }
}