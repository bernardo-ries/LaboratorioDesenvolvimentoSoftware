package com.museu.dao;
import com.museu.model.Livro;
import com.museu.util.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {
    private AuxiliarDAO aux = new AuxiliarDAO();

    public void salvar(Livro livro, String nomeEditora, String nomesAutores, String nomesAssuntos, int idUser) throws SQLException {
        int idEditora = aux.buscarOuCriarEditora(nomeEditora);
        String sql = "INSERT INTO LIVRO (titulo, ano, isbn, numero_paginas, idioma, sinopse, id_editora, status, caminho_capa, id_usuario_resp) VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo', ?, ?)";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, livro.getTitulo());
            stmt.setInt(2, livro.getAno());
            stmt.setString(3, livro.getIsbn());
            stmt.setInt(4, livro.getNumeroPaginas());
            stmt.setString(5, livro.getIdioma());
            stmt.setString(6, livro.getSinopse());
            if(idEditora != -1) stmt.setInt(7, idEditora); else stmt.setNull(7, Types.INTEGER);
            stmt.setString(8, livro.getCaminhoCapa());
            stmt.setInt(9, idUser);
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()) {
                int idLivro = rs.getInt(1);
                processarAutores(idLivro, nomesAutores);
                processarAssuntos(idLivro, nomesAssuntos);
            }
        }
    }

    public void atualizar(Livro livro, String nomeEditora, String nomesAssuntos) throws SQLException {
        int idEditora = aux.buscarOuCriarEditora(nomeEditora);
        String sql = "UPDATE LIVRO SET titulo=?, ano=?, isbn=?, numero_paginas=?, idioma=?, sinopse=?, id_editora=?, caminho_capa=? WHERE id_livro=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, livro.getTitulo());
            stmt.setInt(2, livro.getAno());
            stmt.setString(3, livro.getIsbn());
            stmt.setInt(4, livro.getNumeroPaginas());
            stmt.setString(5, livro.getIdioma());
            stmt.setString(6, livro.getSinopse());
            if(idEditora != -1) stmt.setInt(7, idEditora); else stmt.setNull(7, Types.INTEGER);
            stmt.setString(8, livro.getCaminhoCapa());
            stmt.setInt(9, livro.getId());
            stmt.executeUpdate();
            
            // Atualizar Assuntos (Limpar e Reinserir)
            aux.limparAssuntosLivro(livro.getId());
            processarAssuntos(livro.getId(), nomesAssuntos);
        }
    }
    
    private void processarAutores(int idLivro, String nomes) throws SQLException {
        if(nomes == null || nomes.isEmpty()) return;
        for(String nome : nomes.split(",")) {
            int id = aux.buscarOuCriarAutor(nome);
            if(id != -1) aux.vincularAutorLivro(idLivro, id);
        }
    }
    
    private void processarAssuntos(int idLivro, String nomes) throws SQLException {
        if(nomes == null || nomes.isEmpty()) return;
        for(String nome : nomes.split(",")) {
            int id = aux.buscarOuCriarAssunto(nome);
            if(id != -1) aux.vincularAssuntoLivro(idLivro, id);
        }
    }

    public List<Livro> pesquisar(String filtro, String valor, boolean apenasAtivos) {
        List<Livro> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT l.*, e.nome as nome_editora, " +
            "GROUP_CONCAT(DISTINCT aut.nome SEPARATOR ', ') as autores, " +
            "GROUP_CONCAT(DISTINCT ass.nome SEPARATOR ', ') as assuntos " +
            "FROM LIVRO l " +
            "LEFT JOIN EDITORA e ON l.id_editora = e.id_editora " +
            "LEFT JOIN LIVRO_AUTOR la ON l.id_livro = la.id_livro " +
            "LEFT JOIN AUTOR aut ON la.id_autor = aut.id_autor " +
            "LEFT JOIN LIVRO_ASSUNTO lass ON l.id_livro = lass.id_livro " +
            "LEFT JOIN ASSUNTO ass ON lass.id_assunto = ass.id_assunto "
        );

        if(apenasAtivos) sql.append("WHERE l.status = 'ativo' "); else sql.append("WHERE l.status = 'inativo' ");

        if (!valor.isEmpty()) {
            if (filtro.equals("titulo")) sql.append("AND l.titulo LIKE ? ");
            else if (filtro.equals("ano")) sql.append("AND l.ano = ? ");
            else if (filtro.equals("isbn")) sql.append("AND l.isbn LIKE ? ");
            else if (filtro.equals("editora")) sql.append("AND e.nome LIKE ? ");
            else if (filtro.equals("autor")) sql.append("AND aut.nome LIKE ? ");
            else if (filtro.equals("assunto")) sql.append("AND ass.nome LIKE ? ");
        }
        sql.append("GROUP BY l.id_livro");

        try (Connection conn = Conexao.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            if (!valor.isEmpty()) {
                if (filtro.equals("ano")) { try { stmt.setInt(1, Integer.parseInt(valor)); } catch(Exception e) { return lista; } }
                else stmt.setString(1, "%" + valor + "%");
            }
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(new Livro(
                    rs.getInt("id_livro"), rs.getString("titulo"), rs.getInt("ano"), rs.getString("isbn"),
                    rs.getInt("numero_paginas"), rs.getString("idioma"), rs.getString("sinopse"),
                    rs.getString("status"), rs.getString("caminho_capa"), rs.getString("nome_editora"), 
                    rs.getString("autores"), rs.getString("assuntos")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
    
    public void alterarStatus(int id, String status) throws SQLException {
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement("UPDATE LIVRO SET status = ? WHERE id_livro = ?")) {
            stmt.setString(1, status); stmt.setInt(2, id); stmt.execute();
        }
    }
}