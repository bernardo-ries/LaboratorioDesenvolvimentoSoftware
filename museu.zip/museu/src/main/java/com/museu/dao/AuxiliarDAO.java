package com.museu.dao;
import com.museu.util.Conexao;
import java.sql.*;
public class AuxiliarDAO {
    
    // Método genérico para encontrar ou criar (Editora, Autor, Assunto)
    private int buscarOuCriar(String tabela, String colunaId, String nome) throws SQLException {
        if(nome == null || nome.trim().isEmpty()) return -1;
        String nomeLimpo = nome.trim(); // Remove espaços antes e depois
        
        try (Connection conn = Conexao.getConexao()) {
            PreparedStatement busca = conn.prepareStatement("SELECT " + colunaId + " FROM " + tabela + " WHERE nome = ?");
            busca.setString(1, nomeLimpo);
            ResultSet rs = busca.executeQuery();
            if (rs.next()) return rs.getInt(1);
            
            PreparedStatement cria = conn.prepareStatement("INSERT INTO " + tabela + " (nome) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
            cria.setString(1, nomeLimpo);
            cria.executeUpdate();
            ResultSet rsGen = cria.getGeneratedKeys();
            if (rsGen.next()) return rsGen.getInt(1);
        }
        return -1;
    }

    public int buscarOuCriarEditora(String nome) throws SQLException { return buscarOuCriar("EDITORA", "id_editora", nome); }
    public int buscarOuCriarAutor(String nome) throws SQLException { return buscarOuCriar("AUTOR", "id_autor", nome); }
    public int buscarOuCriarAssunto(String nome) throws SQLException { return buscarOuCriar("ASSUNTO", "id_assunto", nome); }

    public void vincularAutorLivro(int idLivro, int idAutor) throws SQLException {
        try (Connection conn = Conexao.getConexao()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT IGNORE INTO LIVRO_AUTOR (id_livro, id_autor) VALUES (?, ?)");
            stmt.setInt(1, idLivro); stmt.setInt(2, idAutor); stmt.execute();
        }
    }
    
    public void vincularAssuntoLivro(int idLivro, int idAssunto) throws SQLException {
        try (Connection conn = Conexao.getConexao()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT IGNORE INTO LIVRO_ASSUNTO (id_livro, id_assunto) VALUES (?, ?)");
            stmt.setInt(1, idLivro); stmt.setInt(2, idAssunto); stmt.execute();
        }
    }
    
    public void vincularAssuntoRevista(int idRevista, int idAssunto) throws SQLException {
        try (Connection conn = Conexao.getConexao()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT IGNORE INTO REVISTA_ASSUNTO (id_revista, id_assunto) VALUES (?, ?)");
            stmt.setInt(1, idRevista); stmt.setInt(2, idAssunto); stmt.execute();
        }
    }
    
    // Limpar vínculos para edição
    public void limparAssuntosLivro(int idLivro) throws SQLException {
        try (Connection conn = Conexao.getConexao()) {
            conn.createStatement().execute("DELETE FROM LIVRO_ASSUNTO WHERE id_livro = " + idLivro);
        }
    }
    public void limparAssuntosRevista(int idRevista) throws SQLException {
        try (Connection conn = Conexao.getConexao()) {
            conn.createStatement().execute("DELETE FROM REVISTA_ASSUNTO WHERE id_revista = " + idRevista);
        }
    }
}