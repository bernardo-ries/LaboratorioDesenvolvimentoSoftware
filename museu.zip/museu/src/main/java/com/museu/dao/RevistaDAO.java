package com.museu.dao;
import com.museu.model.Revista;
import com.museu.util.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RevistaDAO {
    private AuxiliarDAO aux = new AuxiliarDAO();

    public void salvar(Revista rev, String nomeEditora, String nomesAssuntos, int idUser) throws SQLException {
        int idEditora = aux.buscarOuCriarEditora(nomeEditora);
        String sql = "INSERT INTO REVISTA (titulo, ano, issn, numero_edicao, numero_paginas, idioma, id_editora, status, caminho_capa, id_usuario_resp) VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo', ?, ?)";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, rev.getTitulo());
            stmt.setInt(2, rev.getAno());
            stmt.setString(3, rev.getIssn());
            stmt.setInt(4, rev.getNumeroEdicao());
            stmt.setInt(5, rev.getNumeroPaginas());
            stmt.setString(6, rev.getIdioma());
            if(idEditora != -1) stmt.setInt(7, idEditora); else stmt.setNull(7, Types.INTEGER);
            stmt.setString(8, rev.getCaminhoCapa());
            stmt.setInt(9, idUser);
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()) {
                int idRevista = rs.getInt(1);
                processarAssuntos(idRevista, nomesAssuntos);
            }
        }
    }

    public void atualizar(Revista rev, String nomeEditora, String nomesAssuntos) throws SQLException {
        int idEditora = aux.buscarOuCriarEditora(nomeEditora);
        String sql = "UPDATE REVISTA SET titulo=?, ano=?, issn=?, numero_edicao=?, numero_paginas=?, idioma=?, id_editora=?, caminho_capa=? WHERE id_revista=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, rev.getTitulo());
            stmt.setInt(2, rev.getAno());
            stmt.setString(3, rev.getIssn());
            stmt.setInt(4, rev.getNumeroEdicao());
            stmt.setInt(5, rev.getNumeroPaginas());
            stmt.setString(6, rev.getIdioma());
            if(idEditora != -1) stmt.setInt(7, idEditora); else stmt.setNull(7, Types.INTEGER);
            stmt.setString(8, rev.getCaminhoCapa());
            stmt.setInt(9, rev.getId());
            stmt.executeUpdate();
            
            aux.limparAssuntosRevista(rev.getId());
            processarAssuntos(rev.getId(), nomesAssuntos);
        }
    }
    
    private void processarAssuntos(int idRevista, String nomes) throws SQLException {
        if(nomes == null || nomes.isEmpty()) return;
        for(String nome : nomes.split(",")) {
            int id = aux.buscarOuCriarAssunto(nome);
            if(id != -1) aux.vincularAssuntoRevista(idRevista, id);
        }
    }

    public List<Revista> pesquisar(String filtro, String valor, boolean apenasAtivos) {
        List<Revista> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT r.*, e.nome as nome_editora, GROUP_CONCAT(DISTINCT ass.nome SEPARATOR ', ') as assuntos " +
            "FROM REVISTA r " +
            "LEFT JOIN EDITORA e ON r.id_editora = e.id_editora " +
            "LEFT JOIN REVISTA_ASSUNTO rass ON r.id_revista = rass.id_revista " +
            "LEFT JOIN ASSUNTO ass ON rass.id_assunto = ass.id_assunto "
        );
        if(apenasAtivos) sql.append("WHERE r.status = 'ativo' "); else sql.append("WHERE r.status = 'inativo' ");

        if (!valor.isEmpty()) {
            if (filtro.equals("titulo")) sql.append("AND r.titulo LIKE ? ");
            else if (filtro.equals("ano")) sql.append("AND r.ano = ? ");
            else if (filtro.equals("isbn")) sql.append("AND r.issn LIKE ? ");
            else if (filtro.equals("editora")) sql.append("AND e.nome LIKE ? ");
            else if (filtro.equals("assunto")) sql.append("AND ass.nome LIKE ? ");
        }
        sql.append("GROUP BY r.id_revista");
        
        try (Connection conn = Conexao.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            if (!valor.isEmpty()) {
                if (filtro.equals("ano")) { try { stmt.setInt(1, Integer.parseInt(valor)); } catch(Exception e) { return lista; } }
                else stmt.setString(1, "%" + valor + "%");
            }
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(new Revista(
                    rs.getInt("id_revista"), rs.getString("titulo"), rs.getInt("ano"), rs.getString("issn"),
                    rs.getInt("numero_edicao"), rs.getInt("numero_paginas"), rs.getString("idioma"),
                    rs.getString("status"), rs.getString("caminho_capa"), rs.getString("nome_editora"), rs.getString("assuntos")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }
    
    public void alterarStatus(int id, String status) throws SQLException {
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement("UPDATE REVISTA SET status = ? WHERE id_revista = ?")) {
            stmt.setString(1, status); stmt.setInt(2, id); stmt.execute();
        }
    }
}