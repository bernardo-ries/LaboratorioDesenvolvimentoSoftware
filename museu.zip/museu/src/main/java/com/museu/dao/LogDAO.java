package com.museu.dao;
import com.museu.model.Log;
import com.museu.model.Usuario;
import com.museu.util.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class LogDAO {
    public void registrarLog(String acao, Usuario usuario) {
        String sql = "INSERT INTO LOGS (acao, id_usuario) VALUES (?, ?)";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, acao);
            if(usuario != null) stmt.setInt(2, usuario.getId()); else stmt.setNull(2, Types.INTEGER);
            stmt.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    public List<Log> listarTodos() {
        List<Log> logs = new ArrayList<>();
        String sql = "SELECT l.id_log, l.data_hora, l.acao, u.nome FROM LOGS l LEFT JOIN USUARIO u ON l.id_usuario = u.id_usuario ORDER BY l.data_hora DESC";
        try (Connection conn = Conexao.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while(rs.next()) logs.add(new Log(rs.getInt("id_log"), rs.getString("data_hora"), rs.getString("acao"), rs.getString("nome")));
        } catch (SQLException e) { e.printStackTrace(); }
        return logs;
    }
}