package com.museu.dao;
import com.museu.model.Usuario;
import com.museu.util.Conexao;
import java.sql.*;
public class UsuarioDAO {
    public Usuario autenticar(String login, String senha) {
        String sql = "SELECT * FROM USUARIO WHERE login = ? AND senha = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, login); stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return new Usuario(rs.getInt("id_usuario"), rs.getString("nome"), rs.getString("login"), rs.getString("tipo"));
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
}