package com.museu.model;
public class Livro {
    private int id;
    private String titulo;
    private int ano;
    private String isbn;
    private int numeroPaginas;
    private String idioma;
    private String sinopse; 
    private String status;
    private String caminhoCapa;
    
    // Auxiliares (Strings formatadas para exibição)
    private String nomeEditora;
    private String nomesAutores;
    private String listaAssuntos;

    public Livro() {}
    
    public Livro(int id, String titulo, int ano, String isbn, int paginas, String idioma, String sinopse, String status, String caminhoCapa, String nomeEditora, String nomesAutores, String listaAssuntos) {
        this.id = id; this.titulo = titulo; this.ano = ano; this.isbn = isbn;
        this.numeroPaginas = paginas; this.idioma = idioma; this.sinopse = sinopse;
        this.status = status; this.caminhoCapa = caminhoCapa;
        this.nomeEditora = nomeEditora; this.nomesAutores = nomesAutores; this.listaAssuntos = listaAssuntos;
    }
    
    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getTitulo() { return titulo; } public void setTitulo(String t) { this.titulo = t; }
    public int getAno() { return ano; } public void setAno(int a) { this.ano = a; }
    public String getIsbn() { return isbn; } public void setIsbn(String i) { this.isbn = i; }
    public int getNumeroPaginas() { return numeroPaginas; } public void setNumeroPaginas(int n) { this.numeroPaginas = n; }
    public String getIdioma() { return idioma; } public void setIdioma(String i) { this.idioma = i; }
    public String getSinopse() { return sinopse; } public void setSinopse(String s) { this.sinopse = s; }
    public String getStatus() { return status; } public void setStatus(String s) { this.status = s; }
    public String getCaminhoCapa() { return caminhoCapa; } public void setCaminhoCapa(String c) { this.caminhoCapa = c; }
    public String getNomeEditora() { return nomeEditora; } public void setNomeEditora(String n) { this.nomeEditora = n; }
    public String getNomesAutores() { return nomesAutores; } public void setNomesAutores(String n) { this.nomesAutores = n; }
    public String getListaAssuntos() { return listaAssuntos; } public void setListaAssuntos(String a) { this.listaAssuntos = a; }
}