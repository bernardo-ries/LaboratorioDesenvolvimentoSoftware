package com.museu.model;
public class Log {
    private int id; private String dataHora; private String acao; private String nomeUsuario;
    public Log(int id, String dataHora, String acao, String nomeUsuario) {
        this.id = id; this.dataHora = dataHora; this.acao = acao; this.nomeUsuario = nomeUsuario;
    }
    public int getId() { return id; } public String getDataHora() { return dataHora; }
    public String getAcao() { return acao; } public String getNomeUsuario() { return nomeUsuario; }
}