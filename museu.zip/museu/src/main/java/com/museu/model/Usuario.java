package com.museu.model;
public class Usuario {
    private int id; private String nome, login, tipo;
    public Usuario(int id, String nome, String login, String tipo) {
        this.id = id; this.nome = nome; this.login = login; this.tipo = tipo;
    }
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getTipo() { return tipo; }
}