package com.museu.model;
public class Revista {
    private int id;
    private String titulo;
    private int ano;
    private String issn;
    private int numeroEdicao;
    private int numeroPaginas;
    private String idioma;
    private String status;
    private String caminhoCapa;
    
    private String nomeEditora;
    private String listaAssuntos;

    public Revista() {}

    public Revista(int id, String titulo, int ano, String issn, int numeroEdicao, int paginas, String idioma, String status, String caminhoCapa, String nomeEditora, String listaAssuntos) {
        this.id = id; this.titulo = titulo; this.ano = ano; this.issn = issn;
        this.numeroEdicao = numeroEdicao; this.numeroPaginas = paginas; this.idioma = idioma;
        this.status = status; this.caminhoCapa = caminhoCapa;
        this.nomeEditora = nomeEditora; this.listaAssuntos = listaAssuntos;
    }
    
    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getTitulo() { return titulo; } public void setTitulo(String t) { this.titulo = t; }
    public int getAno() { return ano; } public void setAno(int a) { this.ano = a; }
    public String getIssn() { return issn; } public void setIssn(String i) { this.issn = i; }
    public int getNumeroEdicao() { return numeroEdicao; } public void setNumeroEdicao(int n) { this.numeroEdicao = n; }
    public int getNumeroPaginas() { return numeroPaginas; } public void setNumeroPaginas(int n) { this.numeroPaginas = n; }
    public String getIdioma() { return idioma; } public void setIdioma(String i) { this.idioma = i; }
    public String getStatus() { return status; } public void setStatus(String s) { this.status = s; }
    public String getCaminhoCapa() { return caminhoCapa; } public void setCaminhoCapa(String c) { this.caminhoCapa = c; }
    public String getNomeEditora() { return nomeEditora; } public void setNomeEditora(String n) { this.nomeEditora = n; }
    public String getListaAssuntos() { return listaAssuntos; } public void setListaAssuntos(String a) { this.listaAssuntos = a; }
}