/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import projeto.Conexao;
import projeto.Professor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfessorDAO {
    private Conexao conexao;
    private Connection conn;

    public ProfessorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    // Inserir professor
    public void inserir(Professor professor) {
        String sql = "INSERT INTO professor (nome, sexo, disciplina) VALUES (?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getSexo());
            stmt.setString(3, professor.getDisciplina());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir professor: " + ex.getMessage());
        }
    }

    // Consultar professor por ID
    public Professor getProfessor(int id) {
        String sql = "SELECT * FROM professor WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (!rs.first()) {
                return null; // professor não encontrado
            }

            Professor p = new Professor();
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setSexo(rs.getString("sexo"));
            p.setDisciplina(rs.getString("disciplina"));
            return p;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar professor: " + ex.getMessage());
            return null;
        }
    }

    // Editar professor
    public void editar(Professor professor) {
        String sql = "UPDATE professor SET nome=?, sexo=?, disciplina=? WHERE id=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getSexo());
            stmt.setString(3, professor.getDisciplina());
            stmt.setInt(4, professor.getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar professor: " + ex.getMessage());
        }
    }

    // Excluir professor
    public void excluir(int id) {
        String sql = "DELETE FROM professor WHERE id=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir professor: " + ex.getMessage());
        }
    }
}
