module com.example.teste2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.teste2 to javafx.fxml;
    exports com.example.teste2;
    exports com.example.teste2.model;
    opens com.example.teste2.model to javafx.fxml;
    opens com.example.teste2.controller to javafx.fxml;
}