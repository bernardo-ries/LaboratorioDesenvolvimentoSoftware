/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

import java.sql.*;

public class TesteConexao {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/escola?useTimezone=true&serverTimezone=UTC";
        String usuario = "root";  // seu usuário
        String senha = "1234";    // sua senha

        try {
            // Carrega o driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Conecta ao banco
            Connection conn = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexão realizada com sucesso!");

            // Cria a tabela se não existir
            String criarTabela = "CREATE TABLE IF NOT EXISTS pessoa (" +
                                 "id INT AUTO_INCREMENT PRIMARY KEY, " +
                                 "nome VARCHAR(50) NOT NULL, " +
                                 "sexo CHAR(1) NOT NULL, " +
                                 "idioma VARCHAR(20))";
            Statement stmt = conn.createStatement();
            stmt.execute(criarTabela);

            // Insere alguns dados de teste
            String inserir = "INSERT INTO pessoa (nome, sexo, idioma) VALUES " +
                             "('João', 'M', 'Português'), " +
                             "('Maria', 'F', 'Inglês')";
            stmt.executeUpdate(inserir);

            // Consulta os dados
            String consulta = "SELECT * FROM pessoa";
            ResultSet rs = stmt.executeQuery(consulta);

            System.out.println("Dados da tabela 'pessoa':");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Nome: " + rs.getString("nome") +
                                   ", Sexo: " + rs.getString("sexo") +
                                   ", Idioma: " + rs.getString("idioma"));
            }

            // Fecha recursos
            rs.close();
            stmt.close();
            conn.close();

        } catch (ClassNotFoundException e) {
            System.out.println("Driver MySQL não encontrado!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Erro ao acessar o banco: " + e.getMessage());
            e.printStackTrace();
        }
    }
}